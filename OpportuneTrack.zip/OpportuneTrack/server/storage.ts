import {
  users,
  savedJobs,
  hiddenJobs,
  type User,
  type UpsertUser,
  type SavedJob,
  type InsertSavedJob,
  type HiddenJob,
  type InsertHiddenJob,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Saved jobs operations
  getSavedJobs(userId: string): Promise<SavedJob[]>;
  saveJob(data: InsertSavedJob): Promise<SavedJob>;
  unsaveJob(userId: string, jobId: string): Promise<void>;
  isJobSaved(userId: string, jobId: string): Promise<boolean>;

  // Hidden jobs operations
  getHiddenJobs(userId: string): Promise<HiddenJob[]>;
  hideJob(data: InsertHiddenJob): Promise<HiddenJob>;
  unhideJob(userId: string, jobId: string): Promise<void>;
  isJobHidden(userId: string, jobId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Saved jobs operations
  async getSavedJobs(userId: string): Promise<SavedJob[]> {
    return await db
      .select()
      .from(savedJobs)
      .where(eq(savedJobs.userId, userId));
  }

  async saveJob(data: InsertSavedJob): Promise<SavedJob> {
    const [savedJob] = await db
      .insert(savedJobs)
      .values(data)
      .onConflictDoNothing()
      .returning();
    return savedJob;
  }

  async unsaveJob(userId: string, jobId: string): Promise<void> {
    await db
      .delete(savedJobs)
      .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)));
  }

  async isJobSaved(userId: string, jobId: string): Promise<boolean> {
    const [result] = await db
      .select()
      .from(savedJobs)
      .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)))
      .limit(1);
    return !!result;
  }

  // Hidden jobs operations
  async getHiddenJobs(userId: string): Promise<HiddenJob[]> {
    return await db
      .select()
      .from(hiddenJobs)
      .where(eq(hiddenJobs.userId, userId));
  }

  async hideJob(data: InsertHiddenJob): Promise<HiddenJob> {
    const [hiddenJob] = await db
      .insert(hiddenJobs)
      .values(data)
      .onConflictDoNothing()
      .returning();
    return hiddenJob;
  }

  async unhideJob(userId: string, jobId: string): Promise<void> {
    await db
      .delete(hiddenJobs)
      .where(and(eq(hiddenJobs.userId, userId), eq(hiddenJobs.jobId, jobId)));
  }

  async isJobHidden(userId: string, jobId: string): Promise<boolean> {
    const [result] = await db
      .select()
      .from(hiddenJobs)
      .where(and(eq(hiddenJobs.userId, userId), eq(hiddenJobs.jobId, jobId)))
      .limit(1);
    return !!result;
  }
}

export const storage = new DatabaseStorage();
