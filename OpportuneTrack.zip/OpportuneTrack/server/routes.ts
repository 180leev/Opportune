import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertSavedJobSchema, insertHiddenJobSchema } from "@shared/schema";
import { fromError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Saved jobs routes
  app.get('/api/saved-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const savedJobs = await storage.getSavedJobs(userId);
      res.json(savedJobs);
    } catch (error) {
      console.error("Error fetching saved jobs:", error);
      res.status(500).json({ message: "Failed to fetch saved jobs" });
    }
  });

  app.post('/api/saved-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = insertSavedJobSchema.safeParse({ userId, jobId: req.body.jobId });
      
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }

      const savedJob = await storage.saveJob(result.data);
      res.json(savedJob);
    } catch (error) {
      console.error("Error saving job:", error);
      res.status(500).json({ message: "Failed to save job" });
    }
  });

  app.delete('/api/saved-jobs/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { jobId } = req.params;
      
      await storage.unsaveJob(userId, jobId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unsaving job:", error);
      res.status(500).json({ message: "Failed to unsave job" });
    }
  });

  // Hidden jobs routes
  app.get('/api/hidden-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const hiddenJobs = await storage.getHiddenJobs(userId);
      res.json(hiddenJobs);
    } catch (error) {
      console.error("Error fetching hidden jobs:", error);
      res.status(500).json({ message: "Failed to fetch hidden jobs" });
    }
  });

  app.post('/api/hidden-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = insertHiddenJobSchema.safeParse({ userId, jobId: req.body.jobId });
      
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }

      const hiddenJob = await storage.hideJob(result.data);
      res.json(hiddenJob);
    } catch (error) {
      console.error("Error hiding job:", error);
      res.status(500).json({ message: "Failed to hide job" });
    }
  });

  app.delete('/api/hidden-jobs/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { jobId } = req.params;
      
      await storage.unhideJob(userId, jobId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unhiding job:", error);
      res.status(500).json({ message: "Failed to unhide job" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
