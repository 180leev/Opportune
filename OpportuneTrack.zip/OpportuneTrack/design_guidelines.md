# Opportune Design Guidelines

## Design Approach: Productivity-Focused Design System

**Selected Approach:** Linear/Notion-inspired design system  
**Justification:** As a utility-focused productivity tool for job tracking, Opportune prioritizes efficiency, data clarity, and usability over visual flair. The interface should feel modern and polished while keeping information density and quick scanning as primary goals.

**Core Principles:**
- Clarity over decoration
- Scannable information hierarchy
- Purposeful use of color for status and categorization
- Consistent spatial relationships
- Minimal visual friction

---

## Color Palette

### Light Mode
- **Background:** 0 0% 100% (pure white)
- **Surface:** 240 5% 96% (subtle off-white for cards)
- **Border:** 240 6% 90% (soft gray borders)
- **Text Primary:** 240 10% 10% (near-black)
- **Text Secondary:** 240 5% 45% (muted gray)
- **Primary Brand:** 262 83% 58% (vibrant purple - for CTAs and active states)
- **Success:** 142 71% 45% (green - for "new jobs" indicators)
- **Warning:** 38 92% 50% (amber - for expiring opportunities)

### Dark Mode
- **Background:** 240 10% 8% (deep dark)
- **Surface:** 240 8% 12% (elevated dark cards)
- **Border:** 240 6% 20% (subtle borders)
- **Text Primary:** 0 0% 95% (off-white)
- **Text Secondary:** 240 5% 65% (muted light gray)
- **Primary Brand:** 262 83% 65% (lighter purple for contrast)
- **Success:** 142 71% 55% (brighter green)
- **Warning:** 38 92% 60% (brighter amber)

---

## Typography

**Font Families:**
- Primary: 'Inter' (via Google Fonts CDN) - for UI, body text, and data
- Monospace: 'JetBrains Mono' (via Google Fonts CDN) - for job IDs, dates, technical details

**Type Scale:**
- **Display (Hero):** text-4xl font-bold (36px) - Dashboard welcome heading
- **Heading 1:** text-2xl font-semibold (24px) - Section headers
- **Heading 2:** text-xl font-semibold (20px) - Job card titles
- **Body Large:** text-base font-normal (16px) - Job descriptions
- **Body:** text-sm font-normal (14px) - Metadata, labels
- **Caption:** text-xs font-medium (12px) - Timestamps, tags

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 8, 12, 16 for consistent rhythm
- **Micro spacing:** 2 units (8px) - between inline elements, icon gaps
- **Component spacing:** 4 units (16px) - padding within cards, input fields
- **Section spacing:** 8 units (32px) - between major UI sections
- **Large gaps:** 12-16 units (48-64px) - page margins, hero spacing

**Container Strategy:**
- Dashboard: max-w-7xl mx-auto (1280px max)
- Job cards grid: 3 columns on xl, 2 on lg, 1 on mobile
- Filter sidebar: fixed width of 280px on desktop, drawer on mobile

---

## Component Library

### Navigation & Header
- Fixed top navigation bar with backdrop blur
- Logo/brand left, user profile/auth right
- Transparent background with border-b
- "Update Jobs" button prominently in header (primary color, with loading state)

### Authentication
- Clean centered auth forms (max-w-md)
- Replit Auth button with branded styling
- Minimal decoration, focus on trust indicators

### Job Cards
- Elevated surface with subtle shadow and border
- Clear visual hierarchy: Title → Company → Location/Meta → Description preview
- Color-coded tags for language requirements
- Salary badge if available (subtle, non-distracting)
- Direct apply button (outline variant on card hover)
- Company logo/favicon if available (small, 32x32)

### Filters & Controls
- Collapsible filter sidebar (desktop) / bottom sheet (mobile)
- Multi-select dropdowns with checkboxes
- Date range picker (calendar UI)
- Clear visual feedback for active filters (count badges)
- "Clear all filters" link

### Dashboard Layout
- Split view: Filters (left/drawer) + Job Grid (main)
- Empty state with illustration and "Add companies" CTA
- Loading skeletons matching card dimensions
- Infinite scroll or pagination (20 jobs per page)

### Data Display
- Consistent metadata patterns: Icon + Label format
- Relative timestamps ("2 days ago") with tooltips showing exact date
- Status indicators: "New" badge (green), "Expires soon" (amber)
- Deduplication indicator if same job from multiple sources

### Forms
- Minimal form styling with focus states
- Floating labels for text inputs
- Company selector: searchable dropdown with "Add custom" option
- Role/keyword input: multi-tag input field

---

## Animations

Use sparingly:
- Card hover: subtle lift (translateY -2px) with shadow increase
- Button states: background color transition (150ms)
- Filter drawer: slide animation (300ms ease-out)
- Loading states: simple spinner, no elaborate animations
- New job indicator: subtle pulse animation (once on load)

---

## Images

**No large hero image needed** - this is a utility dashboard, not a marketing page.

**Image Usage:**
- Company logos/favicons: 32x32 or 40x40 within job cards
- Empty state illustration: Simple, minimal line drawing (400x300) centered when no jobs
- User avatars: 32x32 circle in header
- Auth page illustration: Optional small graphic (200x200) above login form

**Image Sources:**
- Company logos: Fetched from Clearbit API or favicon
- Illustrations: Use Undraw or similar free illustration libraries
- Placeholder pattern: Use colored initials for missing logos

---

## Key Screens Structure

**Dashboard:**
- Header with "Update Jobs" CTA
- Filter sidebar/drawer
- Job cards grid (responsive)
- Pagination controls

**Job Detail View:**
- Modal or slide-over panel
- Full description, all metadata
- "Apply Now" primary button with external link icon
- "Save for later" secondary action

**User Settings:**
- Saved filters management
- Company watchlist editing
- Notification preferences (browser notifications toggle)
- Theme switcher (light/dark/system)