import { Button } from "@/components/ui/button";
import { Briefcase, Building2 } from "lucide-react";

interface EmptyStateProps {
  onAddCompanies?: () => void;
}

export function EmptyState({ onAddCompanies }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-center px-4" data-testid="empty-state">
      <div className="bg-muted rounded-full p-6 mb-4">
        <Briefcase className="h-12 w-12 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">No Job Openings Found</h3>
      <p className="text-muted-foreground mb-6 max-w-md">
        Start by selecting companies you want to track, then click "Update Jobs" to fetch the latest opportunities.
      </p>
      {onAddCompanies && (
        <Button onClick={onAddCompanies} data-testid="button-add-companies">
          <Building2 className="h-4 w-4 mr-2" />
          Add Companies
        </Button>
      )}
    </div>
  );
}
