import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExternalLink, MapPin, Building2, Calendar, DollarSign, Languages } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Job } from "./JobCard";

interface JobDetailModalProps {
  job: Job | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function JobDetailModal({ job, open, onOpenChange }: JobDetailModalProps) {
  if (!job) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh]" data-testid="modal-job-detail">
        <DialogHeader>
          <DialogTitle className="text-2xl pr-8" data-testid="text-modal-title">
            {job.title}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(85vh-8rem)]">
          <div className="space-y-4 pr-4">
            <div className="flex items-start gap-2">
              <Building2 className="h-5 w-5 mt-0.5 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="font-semibold text-lg" data-testid="text-modal-company">{job.company}</p>
                <Badge variant="secondary" className="mt-1" data-testid="badge-modal-source">
                  {job.source}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span data-testid="text-modal-location">{job.location}</span>
              </div>
              {job.language && (
                <div className="flex items-center gap-2">
                  <Languages className="h-4 w-4 text-muted-foreground" />
                  <span data-testid="text-modal-language">{job.language}</span>
                </div>
              )}
              {job.salary && (
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span data-testid="text-modal-salary">{job.salary}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span data-testid="text-modal-date">
                  Posted {formatDistanceToNow(job.datePosted, { addSuffix: true })}
                </span>
              </div>
            </div>

            <div className="border-t pt-4">
              <h3 className="font-semibold mb-2">Job Description</h3>
              <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed" data-testid="text-modal-description">
                {job.description}
              </p>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                className="flex-1"
                onClick={() => window.open(job.applyUrl, '_blank')}
                data-testid="button-modal-apply"
              >
                Apply Now <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                data-testid="button-modal-close"
              >
                Close
              </Button>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
