import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, Filter } from "lucide-react";

export interface FilterOptions {
  roles: string[];
  locations: string[];
  languages: string[];
  dateRange: string;
  companies: string[];
}

interface FilterSidebarProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  onClearFilters: () => void;
}

const DATE_RANGES = [
  { value: "24h", label: "Last 24 hours" },
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "all", label: "All time" },
];

export function FilterSidebar({ filters, onFiltersChange, onClearFilters }: FilterSidebarProps) {
  const [roleInput, setRoleInput] = useState("");
  const [locationInput, setLocationInput] = useState("");
  const [languageInput, setLanguageInput] = useState("");

  const addRole = () => {
    const trimmed = roleInput.trim();
    if (trimmed && !filters.roles.includes(trimmed)) {
      onFiltersChange({ ...filters, roles: [...filters.roles, trimmed] });
      setRoleInput("");
    }
  };

  const removeRole = (role: string) => {
    onFiltersChange({ 
      ...filters, 
      roles: filters.roles.filter(r => r !== role) 
    });
  };

  const addLocation = () => {
    const trimmed = locationInput.trim();
    if (trimmed && !filters.locations.includes(trimmed)) {
      onFiltersChange({ ...filters, locations: [...filters.locations, trimmed] });
      setLocationInput("");
    }
  };

  const removeLocation = (location: string) => {
    onFiltersChange({ 
      ...filters, 
      locations: filters.locations.filter(l => l !== location) 
    });
  };

  const addLanguage = () => {
    const trimmed = languageInput.trim();
    if (trimmed && !filters.languages.includes(trimmed)) {
      onFiltersChange({ ...filters, languages: [...filters.languages, trimmed] });
      setLanguageInput("");
    }
  };

  const removeLanguage = (language: string) => {
    onFiltersChange({ 
      ...filters, 
      languages: filters.languages.filter(l => l !== language) 
    });
  };

  const hasActiveFilters = filters.roles.length > 0 || filters.locations.length > 0 || 
                          filters.languages.length > 0 || filters.dateRange !== "all";

  return (
    <div className="h-full flex flex-col border-r bg-background" data-testid="sidebar-filters">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Filters</h2>
          </div>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              data-testid="button-clear-filters"
            >
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Roles Filter */}
          <div>
            <Label htmlFor="role-input" className="text-sm font-medium mb-3 block">
              Roles or Keywords
            </Label>
            <Input
              id="role-input"
              placeholder="e.g., Product Manager..."
              value={roleInput}
              onChange={(e) => setRoleInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addRole();
                }
              }}
              data-testid="input-role"
            />
            {filters.roles.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {filters.roles.map((role) => (
                  <Badge
                    key={role}
                    variant="secondary"
                    className="gap-1 pr-1"
                    data-testid={`badge-role-${role}`}
                  >
                    {role}
                    <button
                      onClick={() => removeRole(role)}
                      className="hover-elevate rounded-full ml-1 p-0.5"
                      data-testid={`button-remove-role-${role}`}
                      aria-label={`Remove ${role}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Locations Filter */}
          <div>
            <Label htmlFor="location-input" className="text-sm font-medium mb-3 block">
              Locations
            </Label>
            <Input
              id="location-input"
              placeholder="e.g., Barcelona..."
              value={locationInput}
              onChange={(e) => setLocationInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addLocation();
                }
              }}
              data-testid="input-location"
            />
            {filters.locations.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {filters.locations.map((location) => (
                  <Badge
                    key={location}
                    variant="secondary"
                    className="gap-1 pr-1"
                    data-testid={`badge-location-${location}`}
                  >
                    {location}
                    <button
                      onClick={() => removeLocation(location)}
                      className="hover-elevate rounded-full ml-1 p-0.5"
                      data-testid={`button-remove-location-${location}`}
                      aria-label={`Remove ${location}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Languages Filter */}
          <div>
            <Label htmlFor="language-input" className="text-sm font-medium mb-3 block">
              Languages
            </Label>
            <Input
              id="language-input"
              placeholder="e.g., English..."
              value={languageInput}
              onChange={(e) => setLanguageInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addLanguage();
                }
              }}
              data-testid="input-language"
            />
            {filters.languages.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {filters.languages.map((language) => (
                  <Badge
                    key={language}
                    variant="secondary"
                    className="gap-1 pr-1"
                    data-testid={`badge-language-${language}`}
                  >
                    {language}
                    <button
                      onClick={() => removeLanguage(language)}
                      className="hover-elevate rounded-full ml-1 p-0.5"
                      data-testid={`button-remove-language-${language}`}
                      aria-label={`Remove ${language}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Date Posted Filter */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Date Posted</Label>
            <div className="space-y-2">
              {DATE_RANGES.map((range) => (
                <div key={range.value} className="flex items-center gap-2">
                  <Checkbox
                    id={`date-${range.value}`}
                    checked={filters.dateRange === range.value}
                    onCheckedChange={() => onFiltersChange({ ...filters, dateRange: range.value })}
                    data-testid={`checkbox-date-${range.value}`}
                  />
                  <label
                    htmlFor={`date-${range.value}`}
                    className="text-sm cursor-pointer flex-1"
                  >
                    {range.label}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
