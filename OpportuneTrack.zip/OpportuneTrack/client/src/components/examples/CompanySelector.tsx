import { useState } from 'react';
import { CompanySelector } from '../CompanySelector';

export default function CompanySelectorExample() {
  const [companies, setCompanies] = useState<string[]>(['SAP', 'Spotify']);

  return (
    <div className="p-8 bg-background">
      <CompanySelector
        selectedCompanies={companies}
        onCompaniesChange={(newCompanies) => {
          console.log('Companies changed:', newCompanies);
          setCompanies(newCompanies);
        }}
      />
      <div className="mt-4">
        <p className="text-sm text-muted-foreground">
          Selected: {companies.join(', ') || 'None'}
        </p>
      </div>
    </div>
  );
}
