import { useState } from 'react';
import { FilterSidebar, type FilterOptions } from '../FilterSidebar';

export default function FilterSidebarExample() {
  const [filters, setFilters] = useState<FilterOptions>({
    roles: ['Software Engineer', 'Designer'],
    locations: ['Remote', 'Copenhagen'],
    languages: ['English'],
    dateRange: '7d',
    companies: [],
  });

  return (
    <div className="h-screen w-80 bg-background">
      <FilterSidebar
        filters={filters}
        onFiltersChange={(newFilters) => {
          console.log('Filters changed:', newFilters);
          setFilters(newFilters);
        }}
        onClearFilters={() => {
          console.log('Filters cleared');
          setFilters({
            roles: [],
            locations: [],
            languages: [],
            dateRange: 'all',
            companies: [],
          });
        }}
      />
    </div>
  );
}
