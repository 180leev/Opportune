import { JobCard } from '../JobCard';

export default function JobCardExample() {
  const sampleJob = {
    id: '1',
    title: 'Senior Product Designer',
    company: 'Spotify',
    location: 'Copenhagen, Denmark',
    language: 'English',
    salary: '€80,000 - €100,000',
    description: 'We are looking for a talented Senior Product Designer to join our team and help shape the future of music streaming. You will work on innovative features that impact millions of users worldwide.',
    source: 'Spotify Careers',
    applyUrl: 'https://spotify.com/careers',
    datePosted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    isNew: true,
  };

  return (
    <div className="p-8 bg-background max-w-2xl">
      <JobCard job={sampleJob} onViewDetails={(job) => console.log('View details:', job)} />
    </div>
  );
}
