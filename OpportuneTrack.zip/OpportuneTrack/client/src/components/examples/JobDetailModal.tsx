import { useState } from 'react';
import { JobDetailModal } from '../JobDetailModal';
import { Button } from '@/components/ui/button';

export default function JobDetailModalExample() {
  const [open, setOpen] = useState(false);

  const sampleJob = {
    id: '1',
    title: 'Senior Product Designer',
    company: 'Spotify',
    location: 'Copenhagen, Denmark',
    language: 'English',
    salary: '€80,000 - €100,000',
    description: `We are looking for a talented Senior Product Designer to join our team and help shape the future of music streaming.

In this role, you will:
• Design innovative features for millions of users
• Collaborate with cross-functional teams
• Create user-centered design solutions
• Lead design thinking workshops
• Mentor junior designers

Requirements:
• 5+ years of product design experience
• Strong portfolio demonstrating UX/UI skills
• Proficiency in Figma and design systems
• Excellent communication skills
• Experience with data-driven design`,
    source: 'Spotify Careers',
    applyUrl: 'https://spotify.com/careers',
    datePosted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    isNew: true,
  };

  return (
    <div className="p-8 bg-background">
      <Button onClick={() => setOpen(true)}>Open Job Detail Modal</Button>
      <JobDetailModal
        job={sampleJob}
        open={open}
        onOpenChange={setOpen}
      />
    </div>
  );
}
