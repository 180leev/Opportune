import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, MapPin, Building2, Calendar, DollarSign, Languages } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  language?: string;
  salary?: string;
  description: string;
  source: string;
  applyUrl: string;
  datePosted: Date;
  isNew?: boolean;
}

interface JobCardProps {
  job: Job;
  onViewDetails?: (job: Job) => void;
}

export function JobCard({ job, onViewDetails }: JobCardProps) {
  return (
    <Card className="p-4 hover-elevate transition-all" data-testid={`card-job-${job.id}`}>
      <div className="flex flex-col gap-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h3 className="text-xl font-semibold text-foreground mb-1 truncate" data-testid={`text-job-title-${job.id}`}>
              {job.title}
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Building2 className="h-4 w-4 flex-shrink-0" />
              <span className="truncate" data-testid={`text-company-${job.id}`}>{job.company}</span>
            </div>
          </div>
          {job.isNew && (
            <Badge className="bg-chart-2 text-white flex-shrink-0" data-testid={`badge-new-${job.id}`}>
              New
            </Badge>
          )}
        </div>

        <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span data-testid={`text-location-${job.id}`}>{job.location}</span>
          </div>
          {job.language && (
            <div className="flex items-center gap-1">
              <Languages className="h-4 w-4" />
              <span data-testid={`text-language-${job.id}`}>{job.language}</span>
            </div>
          )}
          {job.salary && (
            <div className="flex items-center gap-1">
              <DollarSign className="h-4 w-4" />
              <span data-testid={`text-salary-${job.id}`}>{job.salary}</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            <span data-testid={`text-date-${job.id}`}>
              {formatDistanceToNow(job.datePosted, { addSuffix: true })}
            </span>
          </div>
        </div>

        <p className="text-sm text-foreground line-clamp-3" data-testid={`text-description-${job.id}`}>
          {job.description}
        </p>

        <div className="flex items-center justify-between gap-2 pt-2">
          <Badge variant="secondary" className="text-xs" data-testid={`badge-source-${job.id}`}>
            {job.source}
          </Badge>
          <div className="flex gap-2">
            {onViewDetails && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onViewDetails(job)}
                data-testid={`button-details-${job.id}`}
              >
                Details
              </Button>
            )}
            <Button
              size="sm"
              onClick={() => window.open(job.applyUrl, '_blank')}
              data-testid={`button-apply-${job.id}`}
            >
              Apply <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
