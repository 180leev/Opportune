import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Building2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface CompanySelectorProps {
  selectedCompanies: string[];
  onCompaniesChange: (companies: string[]) => void;
}

const SUGGESTED_COMPANIES = ["SAP", "Sonova", "KILROY", "Spotify", "Notion", "Linear"];

export function CompanySelector({ selectedCompanies, onCompaniesChange }: CompanySelectorProps) {
  const [open, setOpen] = useState(false);
  const [customCompany, setCustomCompany] = useState("");

  const addCompany = (company: string) => {
    if (company && !selectedCompanies.includes(company)) {
      onCompaniesChange([...selectedCompanies, company]);
    }
  };

  const removeCompany = (company: string) => {
    onCompaniesChange(selectedCompanies.filter(c => c !== company));
  };

  const handleAddCustom = () => {
    if (customCompany.trim()) {
      addCompany(customCompany.trim());
      setCustomCompany("");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" data-testid="button-select-companies">
          <Building2 className="h-4 w-4 mr-2" />
          Select Companies
          {selectedCompanies.length > 0 && (
            <Badge variant="secondary" className="ml-2">
              {selectedCompanies.length}
            </Badge>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md" data-testid="modal-company-selector">
        <DialogHeader>
          <DialogTitle>Select Companies to Track</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Add custom company..."
              value={customCompany}
              onChange={(e) => setCustomCompany(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleAddCustom();
                }
              }}
              data-testid="input-custom-company"
            />
            <Button onClick={handleAddCustom} size="icon" data-testid="button-add-company">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <p className="text-sm font-medium mb-2 text-muted-foreground">Suggested Companies</p>
            <div className="flex flex-wrap gap-2">
              {SUGGESTED_COMPANIES.map((company) => (
                <Button
                  key={company}
                  variant={selectedCompanies.includes(company) ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    if (selectedCompanies.includes(company)) {
                      removeCompany(company);
                    } else {
                      addCompany(company);
                    }
                  }}
                  data-testid={`button-company-${company}`}
                >
                  {company}
                  {selectedCompanies.includes(company) && (
                    <X className="ml-1 h-3 w-3" />
                  )}
                </Button>
              ))}
            </div>
          </div>

          {selectedCompanies.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-2 text-muted-foreground">Selected Companies</p>
              <div className="flex flex-wrap gap-2">
                {selectedCompanies.map((company) => (
                  <Badge
                    key={company}
                    variant="secondary"
                    className="gap-1"
                    data-testid={`badge-selected-${company}`}
                  >
                    {company}
                    <button
                      onClick={() => removeCompany(company)}
                      className="hover-elevate rounded-full"
                      data-testid={`button-remove-${company}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
