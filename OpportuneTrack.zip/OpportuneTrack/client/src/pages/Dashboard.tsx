import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { FilterSidebar, type FilterOptions } from "@/components/FilterSidebar";
import { JobCard, type Job } from "@/components/JobCard";
import { JobDetailModal } from "@/components/JobDetailModal";
import { CompanySelector } from "@/components/CompanySelector";
import { EmptyState } from "@/components/EmptyState";
import { Briefcase, RefreshCw, LogOut } from "lucide-react";

// TODO: remove mock data - this is just for the design prototype
const MOCK_JOBS: Job[] = [
  {
    id: '1',
    title: 'Senior Product Designer',
    company: 'Spotify',
    location: 'Copenhagen, Denmark',
    language: 'English',
    salary: '€80,000 - €100,000',
    description: 'We are looking for a talented Senior Product Designer to join our team and help shape the future of music streaming. You will work on innovative features that impact millions of users worldwide.',
    source: 'Spotify Careers',
    applyUrl: 'https://spotify.com/careers',
    datePosted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    isNew: true,
  },
  {
    id: '2',
    title: 'Customer Success Manager',
    company: 'SAP',
    location: 'Barcelona, Spain',
    language: 'English, Spanish',
    salary: '€60,000 - €75,000',
    description: 'Join SAP as a Customer Success Manager and help our enterprise clients maximize their investment in our software solutions. Strong communication skills and technical knowledge required.',
    source: 'SAP Careers',
    applyUrl: 'https://sap.com/careers',
    datePosted: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
  },
  {
    id: '3',
    title: 'Software Engineer - Backend',
    company: 'Notion',
    location: 'Remote',
    language: 'English',
    description: 'Build the future of productivity tools at Notion. We are looking for backend engineers passionate about creating scalable systems that power millions of users.',
    source: 'Notion Careers',
    applyUrl: 'https://notion.so/careers',
    datePosted: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    isNew: true,
  },
];

export default function Dashboard() {
  const [filters, setFilters] = useState<FilterOptions>({
    roles: [],
    locations: [],
    languages: [],
    dateRange: 'all',
    companies: [],
  });
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>(['Spotify', 'SAP', 'Notion']);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS);

  const handleViewDetails = (job: Job) => {
    setSelectedJob(job);
    setIsModalOpen(true);
  };

  const handleUpdateJobs = () => {
    setIsUpdating(true);
    // TODO: remove mock functionality - replace with actual API call
    setTimeout(() => {
      console.log('Fetching latest jobs...');
      setIsUpdating(false);
    }, 2000);
  };

  const handleClearFilters = () => {
    setFilters({
      roles: [],
      locations: [],
      languages: [],
      dateRange: 'all',
      companies: [],
    });
  };

  // TODO: remove mock data filtering - replace with actual backend filtering
  const filteredJobs = jobs.filter(job => {
    if (filters.roles.length > 0 && !filters.roles.some(role => job.title.toLowerCase().includes(role.toLowerCase()))) {
      return false;
    }
    if (filters.locations.length > 0 && !filters.locations.some(loc => job.location.includes(loc))) {
      return false;
    }
    if (filters.languages.length > 0 && job.language && !filters.languages.some(lang => job.language?.includes(lang))) {
      return false;
    }
    if (filters.dateRange !== 'all') {
      const now = Date.now();
      const daysDiff = (now - job.datePosted.getTime()) / (1000 * 60 * 60 * 24);
      if (filters.dateRange === '24h' && daysDiff > 1) return false;
      if (filters.dateRange === '7d' && daysDiff > 7) return false;
      if (filters.dateRange === '30d' && daysDiff > 30) return false;
    }
    return true;
  });

  return (
    <div className="h-screen flex flex-col bg-background">
      <header className="border-b bg-background">
        <div className="px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Briefcase className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Opportune</span>
            </div>
            <CompanySelector
              selectedCompanies={selectedCompanies}
              onCompaniesChange={setSelectedCompanies}
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="default"
              onClick={handleUpdateJobs}
              disabled={isUpdating}
              data-testid="button-update-jobs"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Updating...' : 'Update Jobs'}
            </Button>
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.location.href = '/api/logout'}
              data-testid="button-logout"
              aria-label="Log out"
            >
              <LogOut className="h-5 w-5" />
            </Button>
            <Avatar data-testid="avatar-user">
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-80 flex-shrink-0">
          <FilterSidebar
            filters={filters}
            onFiltersChange={setFilters}
            onClearFilters={handleClearFilters}
          />
        </div>

        <main className="flex-1 overflow-auto">
          <div className="max-w-7xl mx-auto p-8">
            <div className="mb-6">
              <h1 className="text-2xl font-semibold mb-2">Job Opportunities</h1>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>Tracking {selectedCompanies.length} companies</span>
                <span>•</span>
                <span>{filteredJobs.length} jobs found</span>
              </div>
            </div>

            {filteredJobs.length === 0 ? (
              <EmptyState />
            ) : (
              <div className="grid gap-4">
                {filteredJobs.map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            )}
          </div>
        </main>
      </div>

      <JobDetailModal
        job={selectedJob}
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
      />
    </div>
  );
}
