import { Button } from "@/components/ui/button";
import { Briefcase, Search, Bell, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Opportune</span>
          </div>
          <Button
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login"
          >
            Log In
          </Button>
        </div>
      </header>

      <main>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-foreground">
              Track Job Openings from Top Companies
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Stay updated on the latest job opportunities from your selected companies with personalized filters for roles, locations, and languages.
            </p>
            <Button
              size="lg"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-get-started"
            >
              Get Started
            </Button>
          </div>
        </section>

        <section className="bg-muted/50 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Search className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Smart Filtering</h3>
                <p className="text-muted-foreground">
                  Filter jobs by role, location, language, and posting date to find exactly what you're looking for.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Manual Updates</h3>
                <p className="text-muted-foreground">
                  Fetch the latest job openings from company career pages with a single click whenever you want.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Bell className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Stay Organized</h3>
                <p className="text-muted-foreground">
                  Track multiple companies and save your filter preferences for quick access to relevant opportunities.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2024 Opportune. Track jobs from top companies effortlessly.</p>
        </div>
      </footer>
    </div>
  );
}
